<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link href="https://fonts.googleapis.com/css?family=Manjari:100,400,700&display=swap" rel="stylesheet">
      <link rel="icon" href="images/favicon.ico" type="image/x-icon">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link rel="stylesheet" href="css/owl.carousel.min.css">
      <link rel="stylesheet" href="css/owl.theme.default.min.css">
      <link rel="stylesheet" href="css/animate.css">
      <link rel="stylesheet" href="css/bootstrap.min.css" >
      <link rel="stylesheet" href="css/style.css" >
      <!-- Global site tag (gtag.js) - Google AdWords: 700262714 -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-700262714"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'AW-700262714');
    </script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-131749240-2"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

  gtag('config', 'UA-131749240-2');
</script>      <title>YogiFi - Your smart Yoga companion</title>
   </head>
   <body >
      <nav class="navbar navbar-expand-lg navbar-light fixed-top">
         <div class="container-fluid pl-md-5 pr-md-5 pl-2 pr-2">
            <a class="navbar-brand" href="index.php">
            <img src="images/logo.png" >
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                     <a class="nav-link" href="index.php">Home</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="practitioners.php">Practitioners</a>
                  </li>
                  <li class="nav-item ">
                     <a class="nav-link" href="trainers.php">Trainers</a>
                  </li>
                  <!--<li class="nav-item ">
                     <a class="nav-link" href="#" >Organizations</a>-->
                  </li>
                  <!--<li class="nav-item ">
                     <a class="nav-link" href="#">Products</a>
                  </li>-->
                  <!--<li class="nav-item">
                     <a class="nav-link" href="https://wellnesys.com/about-us.html" target="_blank">About Us</a>
                  </li>-->
                  <li class="nav-item ">
                     <a href="https://www.yogify.io/cart" class="nav-link" target="_blank"><img src="images/shopping-cart.svg" width="20"></a>
                  </li>
                  <!--<li class="nav-item">
                     <a href="https://www.yogify.io/account/login" class="nav-link" target="_blank"><img src="images/user.png"width="20"> Sign in</a>
                  </li>-->
               </ul>
            </div>
         </div>
      </nav>   
   <!-- <div class="se-pre-con"></div> -->
       <style type="text/css">
        button.close.mdl-close {
          position: absolute;
          background: #fff;
          width: 30px;
          height: 30px;
          z-index: 99999999;
          border-radius: 30px;
          right: 5px;
          top: 5px;
          text-align: center;
          padding: 6px;
        }
        .modal-body video {
          margin-bottom: -8px;
          border-radius: 20px;
        }
        button.close.mdl-close span {
          padding-left: 2px;
        }
        .fixed-top {
          z-index: 99999999;
        }
        .modal-content {
          border-radius: 20px;
          border: 0px;
        }
        .video-hero h1 {
          padding-top: 420px;
        }
        .left-bdr span {
          position: relative;
          z-index: 9999;
          background: #f6f6f6;
          padding: 0px 5px;
        }
        iframe {
          border-radius: 15px !important;
        }
        .smlhead {
          font-size: 26px !important;
          left: 15px !important;
        }
        .d-xs-block {
          display: none;
        }
        .future-of-yoga {
          margin-top: -8px;
          position: relative;
        }
        .future-of-yoga {
          background-image: none !important;
          background-color: #fff !important;
        }
         /**
         * This part should be set separately for each video
         * if there are multiple videos in your site.
         * I.e. '.demo-video-wrapper' is the name of this particular video
         */
         .demo-video-wrapper {
         background-image: url(https://d3k5xyayaartr5.cloudfront.net/_assets/home-video/beach-waves-loop.jpg);
         }

        .fun-practicing, .instructor-led, .numerous-yg, .teacher-can, .track-compare, .beyond-Practice, .our-system, .intelignt-fitnes, .yoga-Instructor, .with-yogifi {
          padding-top: 50px;
          padding-bottom: 50px;
        }

         /* Video overlay and content */
         .video-overlay {
         position: absolute;
         top: 0;
         left: 0;
         bottom: 0;
         right: 0;
         pointer-events: none;
         /* Allows right click menu on the video */
         background: rgba(0,0,0,0.2);
         }
         .video-hero--content {
         position: relative;
         text-align: center;
         color: #FFF;
         margin: 250px 0;
         text-shadow: 0 0 5px rgba(0, 0, 0, 0.4);
         }
         /* CSS from jQuery Background Video plugin */
         /**
         * Set default positioning as a fallback for if the plugin fails
         */
         .jquery-background-video-wrapper {
         position: relative;
         overflow: hidden;
         background-position: center center;
         background-repeat: no-repeat;
         background-size: cover;
         }
         .jquery-background-video {
           width: 100%;
         }
         html {
         scroll-behavior: smooth;
         }
         ul.green-list li {
            font-size: 25px;
            color: #222;
            font-weight: 300;
         }
         .yogiFi .card-title {
              font-size: 32px;
              font-weight: 600;
          }
          .yogiFi .a_box_btn {
            text-decoration: none !important;
                margin: 0 auto;
              padding: 0px 20px;
              font-size: 16px;
              padding-top: 7px !important;
          }
          .yogiFi .a_box_btn:hover {
            color: #222;
            background: #fff;
          }
          .font-size-22 {
                font-size: 22px;
                text-align: left;
                font-weight: 300;
                line-height: 27px;
          }
         /* .our-system, .fun-practicing {
          padding-top: 150px;
          padding-bottom: 150px;
        }*/
        
          .left-bdr {
                font-size: 24px;
          }
          .left-bdr:before {
            width: 100% !important;
          }
          h4.sub-head {
            color: #878787;
            font-weight: 300;
          } 
          h4.sub-head b {
            font-weight: 600;
          }
          footer {
            padding-bottom: 30px !important;
          }
          .item.border {
            border: 2px solid #b9b9b9!important;
            padding-top: 20px;
            padding-bottom: 20px;
          }
          .left-nav, .right-nav {
                padding: 3px 12px 0px;
              border: solid 2px #b9b9b9;
          }
          .lp-pa-322 {
            position: absolute;
            bottom: 0px;
            left: 30px;
            width: auto !important;
            right: 30px;
          }
          .lp-pa-321 {
            position: relative;top: 90px;
          }
          .lp-pa-323 {
            position: relative;top: 190px;
          }
          .lp-pa-324 {
            position: absolute;bottom: 50px;
          }
          .lp-pa-325{
            position: relative;top: 190px;
          }
          .lp-pa-328 {
            margin-top: -190px;
          }
          .owl-theme .owl-nav [class*=owl-]:hover {
            color: #000000 !important;
          }
          .btn-border {
            border: 1px solid #fff;
            border-radius: 30px;
            min-width: 200px;
            font-size: 20px;
            height: 50px;
            text-align: center;
            line-height: 41px;
            margin: 10px;
            transition: 0.3s;
            color: #fff;
            margin-top: 30px;
          }
          .btn-border:hover {
            background: #222;
            color: #fff;
          }
          @media (max-width:768px){
            .video-hero h1 {
              padding-top: 0px;
            }
            .recommends-correction h2.lp-head {
              /*padding-top: 0px !important;*/
              margin-top: 0px !important;
            }
            .our-system img, .numerous-yg img {
              max-width: 80%;
                  margin: auto;
            }
            h2.mob-hd {
              font-size: 18px !important;
            }
            .fun-practicing, .instructor-led, .numerous-yg, .teacher-can, .track-compare, .beyond-Practice, .our-system, .intelignt-fitnes, .yoga-Instructor, .with-yogifi {
              padding-top: 40px;
              padding-bottom: 40px;
            }
            .our-system {
              padding-bottom: 0px !important;
            }
            .mainBanner {
              /*padding-bottom: 80px !important;*/
            }
            .recommends-correction {
              padding-top: 40px !important;
              margin-top: 110px !important;
              padding-bottom: 80px !important;
            }

          .who-is-yogifi {
              padding-top: 80px !important;
            }

            .who-is-yogifi h2.lp-head {
              margin-bottom: 30px !important;
            }
            .smlhead {
              font-size: 16px !important;
            }
            .d-xs-block {
                display: block !important;
              }
              .d-xs-none {
                display: none;
              }
            .smalllp {
              font-size: 16px !important;
            }
            .lp-pa-322 {
                 font-size: 14px !important;
                  margin-left: 0px !important;
                  font-weight: 900 !important;
            }
            .mobile-bg {
              background: #f5f5f5 !important;
            }
            .top-100px {
              margin-bottom: 0px;
            }
            h2.lp-head {
              font-weight: 300;
              margin-bottom: 0px !important;
            }
            .lp-pa-321, .lp-pa-323, .lp-pa-324, .lp-pa-325 {
              position: static !important;
            }
            .lp-pa-328 {
              margin-top: 0px;
            }
            ul.green-list li, .yogiFi .card-title {
              font-size: 20px;
            }
            ul.green-list li:after {
                width: 15px;
                height: 15px;
                left: 5px;
                top: 3px;

          }
          h4.sub-head {
            font-size: 18px;
            margin-bottom: 30px !important;
          }
          
        }
        
        .modal {
          z-index: 9999999;
        }
             
        
        .se-pre-con {
          position: fixed;
          left: 0px;
          top: 0px;
          width: 100%;
          height: 100%;
          z-index: 9999999999;
          background: url(images/Preloader_11.gif) center no-repeat #fff;
              background-size: 40px;
        }
      </style>
      
    <div  id="myDiv" class="animate-bottom">  
      <section class="mainBanner">
         <!-- Start video hero -->
         <div class="video-hero jquery-background-video-wrapper demo-video-wrapper">
            <!-- <video class="jquery-background-video" autoplay muted loop>
               <source src="images/video_yogifi.mp4" type="video/mp4">
              
            </video> -->
             <h1 class="wow fadeInDown" data-wow-duration="1s" data-wow-delay="1s">Take Charge Of Your Inner and Outer Wellbeing
                <div>
                  <a href="#" class="btn btn-border white" data-toggle="modal" data-target="#exampleModal3">Watch Video</a>
                  <a href="https://www.yogify.io/products/yogifi-one-mat" target="_blank" class="btn btn-border white">Pre-Order</a></div>
             </h1>
            <video autoplay="" muted="" loop="" playsinline="" preload="yes" id="myVideo" class="jquery-background-video">
              <source src="images/video_yogifi_v02.mp4" type="video/mp4">
            </video>

            <div class="video-overlay"></div>
            
         </div>
         
      </section>


      <section class="yoga-Instructor future-of-yoga ">
        <!-- <h1 class="text-center lp-head">The Future of Yoga is Here</h1> -->
         <div class="container-fluid pt-0 pt-md-5 pr-md-5">
           
           <div class="row ">
            <div class="col-md-4 d-flex flex-wrap align-content-center order-md-2">
               <h2 class="lp-head pr-0 pr-md-4 wow fadeInRight pt-4 pt-md-0" ><span>The World's ONLY Smart & Personalized Virtual Yoga Instructor</span></h2>
             </div>
             <div class="col-md-8 p-0 order-md-1">
               <img src="images/new-images/future-of-yoga.gif" class="img-fluid w-100">
             </div>
             
           </div>
         </div>

         <!-- <div class="d-md-block" style="background: #F6F6F6;">
           <center>
             <div class="pt-5 pb-5">
                <a href="http://wellnesys.com/yogifi/product-details.php" target="_blank" class="btn btn-border black">Pre-order</a>
                 <a href="#download-app-sec" class="btn btn-border black">Download App</a>
             </div>
           </center>
         </div> -->
      </section>


      <section class="intelignt-fitnes d-flex flex-wrap align-content-center mobile-bg">
         <div class="container-fluid pl-md-5 pr-md-5">
           
           <div class="row ">
              <div class="col-md-12">
                <h2 class="hd-1 lp-head pr-0 pr-md-5 pt-4 pt-md-0 pb-0 mb-0"><div class="wow fadeInRight">Powered by an <span>Intelligent Fitness Mat</span> with <span>Built-in Sensors</span></div></h2>
                <img src="images/new-images/inteligent-fitnes.png" class="img-fluid ml-auto mr-auto d-md-block">
                
                <h2 class="hd-2 lp-head pl-0 pl-md-5 pb-4 pb-md-5 pb-md-0 mb-0"><div class=" wow fadeInLeft">And a unique <span>AI Platform</span> that has been <span>Trained</span> by Our <span>Expert Yoga Teachers</span></div></h2>
              </div>
             <!-- <div class="col-md-4 ">
               
             </div> -->
           </div>
           
         </div>
      </section>




       <section class="our-system d-flex flex-wrap align-content-center " style="background: #fff;">
         <div class="container-fluid pl-md-5 pr-md-5">
           
           <div class="row ">
              

              <div class="col-md-6 order-md-2  ">
                <h2 class="lp-head pl-0 pl-md-5 pt-4 mt-md-0  pt-md-3 mb-0 wow fadeInLeft">Our System <span>Guides</span> you with <br><span>Step-by-Step Instructions</span></h2>
                <img src="images/new-images/guides-step-by-step.png" class="img-fluid ml-auto mr-auto d-md-block">
                
              </div>

              <div class="col-md-6 order-md-1 mobile-bg recommends-correction">
                <div class="row">
                  <div class="col-12 order-md-2">
                    <h2 class="lp-head pl-0 pl-md-5 pt-4 pb-md-3 mt-2 mt-md-0  pt-md-3 pb-0 wow fadeInRight mb-0">
                      And Recommends <span>Correction to your Posture</span> in <span>Real-Time</span></h2>

                  </div>
                  <div class="col-12 order-md-1">
                    <img src="images/new-images/correct-your-posture-new.png" class="img-fluid ml-auto mr-auto d-md-block ">
                  </div>
                </div>
                
                
                
              </div>
             <!-- <div class="col-md-4 ">
               
             </div> -->
           </div>
           
         </div>
      </section>

      <section class="beyond-Practice">
       
         <div class=" container-fluid  pr-md-3 pr-3">
           
           <div class="row ">
             
             <div class="col-md-6 d-flex flex-wrap align-content-center">
               <h2 class="lp-head pl-0 pt-4 pt-md-0 pl-md-5 wow fadeInRight">Beyond the Practice, now you can Measure your <span>Strength, Flexibility, Balance and Endurance</span> after each Session</h2>
             </div>
             <div class="col-md-6 pr-0 pt-0 pt-md-5 text-right">
               <img src="images/new-images/strength-flexibility.jpg" class="img-fluid">
             </div>
           </div>
         </div>
      </section>


      <section class="track-compare mobile-bg" style="background: #fff;">
       
         <div class="container-fluid pl-md-0 pl-0" style="position: relative;">
           
           <div class="row ">
             
             
             <div class="col-md-6 p-0 text-right">
               
             </div>
             <div class="col-md-6 d-flex flex-wrap align-content-center">
               <h2 class="lp-head pl-3 pl-md-0 pr-0 pr-md-5 wow fadeInRight lp-pa-321">And <span>Track & Compare</span> your <span>Vitals</span> Before and After the Workout</h2>
             </div>
           </div>
           <h2 class="lp-head pr-0 pl-md-5 ml-3 wow fadeInLeft lp-pa-322 smlhead">Works with Apple Watch & Fitbit</h2>
           <img src="images/new-images/track-compare.png" class="img-fluid">
         </div>
      </section>




      <section class="teacher-can ">
       
         <div class="container-fluid pt-4 mb-4 mb-md-0 pt-md-5 pl-md-0 pl-0 " style="position: relative;">
           
           <div class="row ">
             
             
             <div class="col-md-8 offset-md-3 d-flex flex-wrap align-content-center">
               <h2 class="lp-head pl-3 pl-md-0 pr-0 pr-md-5 wow fadeInRight lp-pa-323">Your <span>Teacher</span> can <span>Monitor your Practice</span> Remotely and Provide <span>Personalized Guidance</span></h2>
             </div>
           </div>
           <img src="images/new-images/monitor-your-practice.png" class="img-fluid">
         </div>
      </section>


 <section class="numerous-yg mobile-bg" style="background: #fff;">
       
         <div class="container-fluid pt-0 pt-md-5 pl-md-5 pl-3">
           
           <div class="row ">
             <div class="col-md-7 d-flex flex-wrap align-content-center wow fadeInLeft order-md-2">
               <h2 class="lp-head pr-0 pr-md-5 pb-0 mb-2 pb-md-4"><span>Numerous Yoga Programs</span> for your <span>Daily Wellness</span> that you can Choose</h2>
               <h2 class="lp-head pr-0 pr-md-5 smalllp d-xs-none smlhead" style="font-weight: 400;">All Programs are Curated by Global Yoga Teachers</h2>
             </div>
             <div class="col-md-5 text-left pl-md-5 pl-3 pr-md-5 pr-3 order-md-1">
               <img src="images/new-images/numerous-yoga.jpg" class="img-fluid top-100px d-xs-none">
               <img src="images/new-images/numerous-yoga.png" class="img-fluid d-xs-block mt-2 mb-3">
               <h2 class="lp-head pr-0 pr-md-5 smalllp  d-xs-block smlhead" style="font-weight: 400;">All Programs are Curated by Global Yoga Teachers</h2>
             </div>

            
             
           </div>
         </div>
      </section>




        
 <section class="instructor-led">
       
         <div class="container-fluid pt-0 pt-md-5 pl-md-0 pl-0" style="position: relative;">
           
           <div class="row ">
             
             
             <div class="col-md-8 text-right wow fadeInRight lp-pa-328">
               <h2 class="lp-head pl-3 pl-md-0 pl-0 pl-md-5 pr-0 pr-md-5 text-left lp-pa-325" style="">You can even Join a <span>Live Instructor-Led session</span> Through <span>YogiFi Digital</span></h2>
             </div>
             <div class="col-md-4 ">
               
             </div>
           </div>
           
           <img src="images/new-images/live-instructor-led.png" class="img-fluid">
           <div class="row ">
             
             
             <div class="col-md-4 text-right">
               
             </div>
             <div class="col-md-8 wow fadeInUp">
               <h2 class="lp-head pr-0 pl-md-5 ml-3 lp-pa-324" style="">With <span>Real-Time Tracking</span><br>by <span>YogiFi Mat</span></h2>
             </div>
           </div>
         </div>
      </section>




      <section class="fun-practicing mobile-bg" style="background: #fff;">
       
         <div class="container-fluid pt-4 pt-md-5 pl-md-0 pl-0" style="position: relative;">
           <div class="container">
             <div class="row ">
             
             
             <div class="col-md-12 text-left">
               <h2 class="lp-head  pl-0  pr-0 pr-md-5 wow fadeInUp">You can now have <span>Fun while Practicing Yoga</span><br>by Inviting <span>Friends</span> to Practice Together Anytime</span></h2>
             </div>
             
           </div>
           
           <img src="images/new-images/invite-friends.png" class="img-fluid ml-auto mr-auto d-block">
           <div class="row ">
             
             
            
             <div class="col-md-12 text-left">
               <h2 class="lp-head pr-0  wow fadeInUp">And Enter in <span>Healthy and Motivating Challenges</span><br> for a <span>Playful Yoga</span> Practice</h2>
             </div>
           </div>
           </div>
           
         </div>
      </section>





      

      <section class="yogiFi-work min-hgt-500 for-maitain-height with-yogifi ">
         
         <div class="container pt-0 pt-md-5">
            <div class="row pt-0 mt-0">
               <div class="col-12 col-md-4 col-lg-6  position-relative order-md-2 pb-4 pb-md-0">
                  <div class="text-right">
                     <img src="images/new-images/with-yogifi.png" class="img-fluid cntrMb" alt="The Future of Yoga">
                  </div>
               </div>
               <div class="col-12 col-md-8 col-lg-6   left-list  text-left order-md-1 wow fadeInUp">
                  <h2 class="lp-head pb-0 pb-md-3"><span>With YogiFi</span></h2>
                  <!-- <h2 class="font-700 ">How YogiFi works</h2>
                  <p class="font-size-20 font-100">The technology behind the magic</p> -->
                  <ul class="green-list  mb-4">
                     <li>You will never have to miss a yoga session due to time constraints</li>
                     <li>You will never feel Yoga is Boring</li>
                     <li>You will never feel lost with figuring out right sessions</li>
                     <li>You can practice at your own pace</li>
                     <li>You always get personalized attention from the teachers</li>
                     
                  </ul>   
                  <h2 class="lp-head pt-2"><span>And you are Never Alone while Practicing Yoga Anywhere/Anytime</span></h2>               
               </div>
               
            </div>
         </div>
      </section>
       <section class="yogiFi min-hgt-500 for-maitain-height pt-4 pb-4 pt-md-5 pb-md-5 text-center who-is-yogifi" style="background: #fff;">
         <div class="container">
             <h2 class="lp-head pb-0 pb-md-3 wow fadeInUp"><span>Who is YogiFi for?</span></h2>
            <div class="row">
               <div class="col-sm">
                  <div class="card   text-white rounded-0 border-0">
                     <img class="img-fluid " src="images/yoga-practitioners.jpg" alt="yoga practitioners">
                     <div class="card-img-overlay">
                        <h5 class="card-title">Yoga Practitioners</h5>
                        <a href="practitioners.php" class="a_box_btn  pt-1 pb-1">Learn more</a>    
                     </div>
                  </div>
               </div>
               <div class="col-sm">
                  <div class="card   text-white rounded-0 border-0">
                     <img class="img-fluid " src="images/trainers.jpg" alt="trainers">
                     <div class="card-img-overlay">
                        <h5 class="card-title">Trainers</h5>
                        <a href="trainers.php" class="a_box_btn   pt-1 pb-1">Learn more</a>    
                     </div>
                  </div>
               </div>
               <div class="col-sm">
                  <div class="card   text-white rounded-0 border-0">
                     <img class="img-fluid " src="images/organizations.jpg" alt="Organizations">
                     <div class="card-img-overlay">
                        <h5 class="card-title">Organizations</h5>
                        <!-- <a href="#"  class="a_box_btn   pt-1 pb-1">Learn more</a> -->
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="yogiFi-work pt-4 pb-4 pt-md-5 pb-md-5 mt-5" style="background: #F6F6F6;">
         <div class="container text-center">
           <h2 class="lp-head pb-0"><span>What are People Saying?</span></h2>
            <h4 class="sub-head mb-5"><b>YogiFi</b> is taking the yoga world by storm!</h4>
            <div class="col-12 col-lg-10 offset-lg-1">
               <div class="owl-carousel owl-theme pl-lg-5 pr-lg-5 pr-0 pl-0" id="foodtrought-owl">
                  <div class="item wow fadeInLeft">
                     <div class="card bg-none border-0">
                        <iframe  height="220" src="https://www.youtube.com/embed/39h8SsL06hU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        <div class="card-body pl-0 pr-0">
                           <p class="card-text font-size-20 font-size-22">I am very excited that YogiFi will enable me to do yoga outdoors. Also, I am a frequent traveler. So, with YogiFi, I will feel more accountable and will be able to practice yoga more regularly.</p>
                           <h5 class="left-bdr  left-0 text-right mb-0"><span>Tom, San Diego</span></h5>
                        </div>
                     </div>
                  </div>
                  <div class="item wow fadeInRight">
                     <div class="card bg-none border-0">
                        <iframe height="220" src="https://www.youtube.com/embed/Idtd6udYOeI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        <div class="card-body pl-0 pr-0">
                           <p class="card-text font-size-20 font-size-22">I am an ardent yogi and many of my friends practice yoga as well. I am very excited that I can have a yoga challenge with my friends with the app. I am looking forward to it.</p>
                           <h5 class="left-bdr right0 text-left mb-0"><span>Joanna, UK</span></h5>
                        </div>
                     </div>
                  </div>  
               </div>
            </div>
         </div>
      </section>
      <section class="award pt-4 pb-4 pt-md-5 pb-md-5 mb-md-5" style="background: #fff;">
         <div class="container">
            <h2 class="font-700 text-center ">Award-Winning Cutting-Edge Innovation</h2>
            <h4 class="font-100 text-center pb-4">Most Influential Consumer Tech || Top Start-up Award || Most Innovative Fitness Tech Company</h4>
            <div class="owl-carousel owl-theme pl-lg-5 pr-lg-5 pr-0 pl-0" id="awards-owl">
               <div class="item wow fadeInLeft border text-center">
                  <img src="images/awards-01.png" alt="Card image"  width="150" class="m-auto">
               </div>
               <div class="item wow fadeInRight border text-center">
                  <img src="images/awards-02.png" alt="Card image"   width="150" class="m-auto">
               </div>
               <div class="item wow fadeInRight border text-center">
                  <img src="images/awards-03.png" alt="Card image"   width="150" class="m-auto">
               </div>
               <div class="item wow fadeInRight border text-center">
                  <img src="images/awards-01.png" alt="Card image"   width="150" class="m-auto">
               </div>
               <div class="item wow fadeInRight border text-center">
                  <img src="images/awards-02.png" alt="Card image"   width="150" class="m-auto">
               </div>
            </div>
         </div>
      </section>
      <section class="yogiFi-mat min-hgt-300 for-maitain-height pt-5 pb-5 mb-md-5" id="download-app-sec" style="background:#F6F6F6 url(images/ft-bg.png); ">
         <div class="container">
            <div class="row">               
               <div class="col-12 col-md-6 text-center">
                  <h2 class="font-700 mob-hd">Download free <img src="images/logo_black.png" width="100" alt="yogiFi" style="display: inline !important;"> app now!</h2>
                 <div class="m-auto text-center"><a href="https://play.google.com/store/apps/details?id=com.yogifi.application&hl=en" target="_blank" class=""><img src="images/google-play.png" width="130" alt="yogiFi App in play store" style="display: inline !important;"></a>
                  <a href="https://apps.apple.com/in/app/yogifi/id1447600497" target="_blank" class="ml-4"><img src="images/app-store.png" style="display: inline !important;"  width="130" alt="yogiFi App in app store"></a>
               </div>
               </div>
               <div class="col-12 col-md-5 position-relative">
                  <div class="img-over m-auto">
                     <img src="images/iPhoneX_Mockup_2.png" alt="The Future of Yoga" class="d-none d-md-block wow fadeInRight">
                  </div>
               </div>
            </div>
         </div>
      </section>

      <div class="modal fade bd-example-modal-lg" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModal3Label" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      
      <div class="modal-body p-0" style="position: relative;">
        <button type="button" class="close mdl-close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <video  id="myVideo2" style="width: 100%;" controls>
              <source src="images/video_yogifi_v02.mp4" type="video/mp4">
            </video>
      </div>
      <!-- <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div> -->
    </div>
  </div>
</div>
</div>
<!-- <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script> -->
      <!-- Event snippet for Sales conversion page -->
                {% if first_time_accessed %}
                <script>
                  gtag('event', 'conversion', {
                      'send_to': 'AW-700262714/xJEeCOHcuLUBELrS9M0C',
                      'value': {{ total_price | money_without_currency | remove: "," }},
                      'currency': '{{ shop.currency }}',
                      'transaction_id': '{{ order.order_number }}'
                  });
                </script>
                {% endif %}

		<footer class="pt-md-5 pb-3">
         <div class="container-fluid pl-md-5 pr-md-5">
            <div class="row">
               
               <div class="col-sm-12 col-md-8 ">
                  <div class="row">
                     
                     <div class="col-sm ">
                        <h4 class="pt-2 pb-2"><b>Navigation</b></h4>
                        <ul>
                           <li><a href="yoga-practitioners.php">Practitioners</a></li>
                           <li><a href="trainers.php">Trainers</a></li>
                           <!--<li><a href="#">Organizations</a></li>-->
                           <!--<li><a href="#">Products</a></li>-->
                           <li><a href="https://wellnesys.com/about-us.html">About Us</a></li>
                        </ul>
                     </div>
                     <div class="col-sm">
                        <h4 class="pt-2 pb-2"><b>Company</b></h4>
                        <ul>
                           <li><a href="https://www.yogify.io/cart" target="_blank">Shop</a></li>
                           <li><a href="https://www.wellnesys.com/news.html" target="_blank">News & Press</a></li>
                           <!--<li><a href="https://www.yogify.io/account/login" target="_blank">Sign In</a></li>-->
                           <li><a href="https://www.wellnesys.com/contact-us.html" target="_blank">Contact Us</a></li>
                        </ul>
                     </div>
                     <div class="col-sm">
                        
                     </div>
                  </div>
               </div>
               <div class="col-12 col-md-4 ">
                  <div class=" text-right">
                  <img src="images/logo_black.png" class="img-fluid" >
                  <p class="pt-3">YogiFi is a smart virtual yoga instructor that offers personalized wellness programs on an intelligent yoga mat that tracks various exercise, postures, provides real-time correctional feedback, and correlates body vitals from wearables.</p>
                 
               </div>
               </div>
            </div>
            <div class="row mt-md-3">
            <div class="col-sm border-top copyright ">
               <div class="mb-4 mb-md-0 pt-md-3 "><p class="d-inline ">International Patent Pending. Copyright @2019. YOGIFI All Rights Reserved</p><a href="http://www.wellnesys.com/privacy.html" target="_blank" class="d-inline pl-md-3">Privacy Policy</a>  <a href="http://www.wellnesys.com/legal.html"  target="_blank" class="d-inline pl-2 pl-md-3">Legal</a></div>
            </div>
             <div class="col-sm solcial mb-center">
                     <ul class="float-right">
                        <!--<li>
                           <a href="https://accounts.google.com/AccountChooser/signinchooser?service=lbc&continue=https%3A%2F%2Fbusiness.google.com%2Fdashboard%2Fl%2F08059107266702732155%3Facct_rdr%3D1&flowName=GlifWebSignIn&flowEntry=AccountChooser" target="_blank"><i class="fa fa-google" aria-hidden="true"></i></a>
                        </li>-->
                        <li>
                           <a href="https://www.linkedin.com/company/wellnesys" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                        </li>
                        <li>
                           <a href="https://www.facebook.com/yogifiio" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        </li>
                        <li>
                           <a href="https://twitter.com/YogiFi_Me" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                        </li>
                        <li>
                           <a href="https://www.instagram.com/p/BkZbUnDBkE4/?hl=en" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                        </li>
                     </ul>
                  </div>
               </div>
         </div>
      </footer>      <!-- Optional JavaScript -->
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="js/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/wow.js"></script> 
      <script src="js/owl.carousel.js"></script>

  <!-- <script type="text/javascript">
     $(window).load(function() {
      $(".se-pre-con").fadeOut("slow");;
    });
  </script> -->
 <script type="text/javascript">
         $(window).scroll(function() {

           if ($(this).scrollTop() > 100){  
               $('.navbar-expand-lg').addClass("navbar-shrink");
             }
             else{
               $('.navbar-expand-lg').removeClass("navbar-shrink");
             }
           });
      </script>
      <script>
         $(document).ready(function() {
           var owl = $('#foodtrought-owl');
           owl.owlCarousel({
             margin: 50,
             nav: false,
             dots: true,
             loop: false,
             navText: [""],
             responsive: {
               0: {
                 items: 1
               },
               600: {
                 items: 2
               },
               1000: {
                 items: 2
               }
             }
           });
         var owl = $('#awards-owl');
           owl.owlCarousel({
             margin: 30,
             nav: true,
             dots: false,
             autoplay:true,
             autoplayTimeout:3000,
             autoplayHoverPause:true,
             loop: false,
             navText: ["<div class='left-nav'><i class='fa fa-angle-left'></i></div>", "<div class='right-nav'><i class='fa fa-angle-right'></i></div>"],
             responsive: {
               0: {
                 items: 1
               },
               600: {
                 items: 2
               },
               1000: {
                 items: 3
               }
             }
           })
            
         })
      </script>
      <script>
         wow = new WOW(
           {
             animateClass: 'animated',
             offset:       100,
             callback:     function(box) {
               console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
             }
           }
         );
         wow.init();
         document.getElementById('moar').onclick = function() {
           var section = document.createElement('section');
           section.className = 'section--purple wow fadeInDown';
           this.parentNode.insertBefore(section, this);
         };
      </script>
      <script type="text/javascript" src="js/custom.js"></script>
      <script type="text/javascript">
         $('.seachbtn').on('click', function(){
           $(this).toggleClass('toggleshow')
           $('.searchBox').toggle().toggleClass('show');
         })
      </script>


     
   </body>
</html>
