<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link href="https://fonts.googleapis.com/css?family=Manjari:100,400,700&display=swap" rel="stylesheet">
      <link rel="icon" href="images/favicon.ico" type="image/x-icon">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link rel="stylesheet" href="css/owl.carousel.min.css">
      <link rel="stylesheet" href="css/owl.theme.default.min.css">
      <link rel="stylesheet" href="css/animate.css">
      <link rel="stylesheet" href="css/bootstrap.min.css" >
      <link rel="stylesheet" href="css/style.css" >
      <!-- Global site tag (gtag.js) - Google AdWords: 700262714 -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-700262714"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'AW-700262714');
    </script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-131749240-2"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

  gtag('config', 'UA-131749240-2');
</script>      <title>YogiFi - Practise Yoga your way</title>
   </head>
   <body >
      <nav class="navbar navbar-expand-lg navbar-light fixed-top">
         <div class="container-fluid pl-md-5 pr-md-5 pl-2 pr-2">
            <a class="navbar-brand" href="index.php">
            <img src="images/logo.png" >
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                     <a class="nav-link" href="index.php">Home</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="practitioners.php">Practitioners</a>
                  </li>
                  <li class="nav-item ">
                     <a class="nav-link" href="trainers.php">Trainers</a>
                  </li>
                  <!--<li class="nav-item ">
                     <a class="nav-link" href="#" >Organizations</a>-->
                  </li>
                  <!--<li class="nav-item ">
                     <a class="nav-link" href="#">Products</a>
                  </li>-->
                  <!--<li class="nav-item">
                     <a class="nav-link" href="https://wellnesys.com/about-us.html" target="_blank">About Us</a>
                  </li>-->
                  <li class="nav-item ">
                     <a href="https://www.yogify.io/cart" class="nav-link" target="_blank"><img src="images/shopping-cart.svg" width="20"></a>
                  </li>
                  <!--<li class="nav-item">
                     <a href="https://www.yogify.io/account/login" class="nav-link" target="_blank"><img src="images/user.png"width="20"> Sign in</a>
                  </li>-->
               </ul>
            </div>
         </div>
      </nav> 
      <section class="banner inner-banner" style="background-image: url(images/yoga-practitioners-bnr.jpg) !important; background-size: cover;background-position: center center;">
         <div class="container text-center p-0">
            <h1 class=" wow fadeInDown">Yoga Practitioners</h1>
            <!--<h3 class="white-text font-400 mb-4 mb-md-5">Lorem ipsum dolor sit amet consectetur</h3>-->
             
         </div>
      </section>
      <section class="min-hgt-300 for-maitain-height pt-4 pb-4 pt-md-5 pb-md-5 position-relative">
         <div class="container">
         <div class="row">
            <div class="col-12 col-md-8">
               <h2 class="font-700">YogiFi is Yoga Your Way</h2>
               <p class="font-size-20 mb-4 mb-md-5">You are unique, so the way you practice yoga should be, too. YogiFi monitors your practice and measures your progress, and offers personalized programs that are optimal for your style. You can even get personalized guidance from teachers in the YogiFi Community to take your practice to the next level. No matter your style or level, yoga is simply better with YogiFi.</p> 
            </div>
            <div class="col-12 col-md-4">
                 
               <div class="img-bg right-img-0">
                  <img src="images/yoga-your-way.png" class="img-fluid img-in-bg">
               </div>

            </div>
         </div>
      </div>
      </section>
      <section class="with-yogifi min-hgt-500 for-maitain-height pt-4 pb-4 pt-md-5 pb-md-5">
         <div class="container">
            <div class="row">
               
               <div class="col-12 col-md-8 text-right  order-md-2">
               <h2 class="font-700">With YogiFi, You’re Never Alone</h2>
               <p class="font-size-20 mb-4 mb-md-5">Now you always have a yoga partner - anywhere, anytime. YogiFi walks you through your asanas, step by step, gently guiding you along the way to better posture. Our trained instructors specialize in whatever you need, and are available at the touch of a button, across the globe. With YogiFi’s recurring challenges, you can even practice yoga together with family and friends around the world.</p> 
            </div>
            <div class="col-12 col-md-4  order-md-1">
                 
               <div class="img-bg left-img-0">
                  <img src="images/with-yogifi.png" class="img-fluid img-in-bg">
               </div>

            </div>
            </div>
         </div>
      </section>
      <section class="min-hgt-300 for-maitain-height pt-4 pb-4 pt-md-5 pb-md-5 position-relative">
         <div class="container">
         <div class="row">
            <div class="col-12 col-md-8 left-list">
               <h2 class="font-700">Enjoy Flexibility, Freedom, and Fun With YogiFi</h2>
               <p class="font-size-20 font-100">YogiFi sets you free from the limitations of traditional yoga practice</p>

               <div class="line-right" style="bottom: -49px !important;"></div>
               <ul class="small-font green-list mb-3 left5">
                     <li class="font-size-20">Busy professionals can arrange sessions around their changing schedule.</li>
                     <li class="font-size-20">Frequent travelers never have to miss their routine when they’re on the road.</li>
                     <li class="font-size-20">Differently-abled people now have the freedom to practice under a teacher’s guidance at home.</li>
                     <li class="font-size-20">Senior citizens and pregnant women can also practice from the comfort of home at their own pace under a teacher’s guidance.</li>
                     <li class="font-size-20">YogiFi’s unique gamification modes keeps millennials and kids engaged and motivated.</li>
                     <li class="font-size-20">There are even specially-designed recovery routines for sports professionals. </li>
                  </ul> 
                  <p class="font-size-20" style="padding-left: 30px;">No matter where you are in your wellness journey, YogiFi fits your life!</p>
            </div>
            <div class="col-12 col-md-4">
                 
               <div class="img-bg right-img-0">
                  <img src="images/flexibility.png" class="img-fluid img-in-bg" alt="Enjoy Flexibility, Freedom, and Fun With YogiFi">
               </div>

            </div>
         </div>
      </div>
      </section>
      <section class="its-simple min-hgt-500 for-maitain-height pt-4 pb-4 pt-md-5 pb-md-5">
         <div class="container">
            <div class="row">
               
               <div class="col-12 col-md-8 text-right order-md-2">
               <h2 class="font-700">It’s Simple to Get Started With YogiFi</h2>
               <p class="font-size-20">YogiFi makes it quick and easy to start seeing real results. Simply download the mobile app to create your account and set up your profile.  Choose a program that fits your fitness and wellness goals - don’t worry, you can change it at any time. </p>


                  <div class="line-right" style="bottom: -98px !important;"></div>
                  <ul class="green-list mb-4 ">
                     <li class="font-size-20">Create a YogiFi account and build your profile using the YogiFi Student Mobile App</li>
                     <li class="font-size-20">Select/subscribe to a program based on your fitness/wellness goals</li>
                     <li class="font-size-20">Turn on the YogiFi Mat and begin the session</li>
                     <li class="font-size-20">Follow the instructions from the virtual instructor</li>
                     <li class="font-size-20">Review the session summary and body vitals at the end of the session</li>
                  </ul>  
            </div>
            <div class="col-12 col-md-4 order-md-1">
                 
               <div class="img-bg left-img-0">
                  <img src="images/simple-to-get.png" class="img-fluid img-in-bg" alt="It’s Simple to Get Started With YogiFi">
               </div>

            </div>
            </div>
         </div>
      </section>
      <!--<s ection class="how-does min-hgt-500 for-maitain-height pt-4 pb-4 pt-md-5 pb-md-5">
         <div class="container-fluid">
            <div class="row">
               <div class="col-12 col-md-6 position-relative">
                  <div class="img-over top-60" style="left: 0px !important;">
                     <img src="images/how-does.jpg" alt="How Does YogiFi Work?">
                  </div>
               </div>
               <div class="col-12 col-md-6 ">
                  
               </div>
               
            </div>
         </div>
      </section> -->
      <section class="yogiFi-mat for-maitain-height pt-4 pb-4 pt-md-5 pb-md-5" style="background:#00C6BB ">
         <div class="container">
            <div class="row">               
               <div class="col-12 col-md-6 text-center">
                  <h2 class="white-text">Step into your Best with YogiFi</h2>
                  <a href="http://wellnesys.com/yogifi/product-details.php" target="_blank" class="a_box_btn text-uppercase pl-4 pr-4 pt-2 pb-1">Pre-Order Today</a>
               </div>
            </div>
         </div>
      </section>         
      <section class="yogiFi-mat min-hgt-300 for-maitain-height pt-4 pb-4 pt-md-5 pb-md-5 mb-md-5 inner-page-footer" style="background:#F6F6F6 url(images/ft-bg.png); ">
         <div class="container">
            <div class="row">               
               <div class="col-12 col-md-6 text-center">
                  <h2 class="font-700">Download free <img src="images/logo_black.png" width="100" alt="yogiFi"> app now!</h2>
                 <div class="m-auto text-center"><a href="https://play.google.com/store/apps/details?id=com.yogifi.application&hl=en" target="_blank" class=""><img src="images/google-play.png" width="100" alt="yogiFi App in play store"></a>
                  <a href="https://apps.apple.com/in/app/yogifi/id1447600497" target="_blank" class="ml-4"><img src="images/app-store.png"  width="100" alt="yogiFi App in app store"></a>
               </div>
               </div>
               <div class="col-12 col-md-5 position-relative">
                  <div class="img-over m-auto">
                     <img src="images/iPhoneX_Mockup_2.png" alt="The Future of Yoga" class="d-none d-md-block">
                  </div>
               </div>
            </div>
         </div>
      </section>
            <!-- Event snippet for Sales conversion page -->
                {% if first_time_accessed %}
                <script>
                  gtag('event', 'conversion', {
                      'send_to': 'AW-700262714/xJEeCOHcuLUBELrS9M0C',
                      'value': {{ total_price | money_without_currency | remove: "," }},
                      'currency': '{{ shop.currency }}',
                      'transaction_id': '{{ order.order_number }}'
                  });
                </script>
                {% endif %}

		<footer class="pt-md-5 pb-3">
         <div class="container-fluid pl-md-5 pr-md-5">
            <div class="row">
               
               <div class="col-sm-12 col-md-8 ">
                  <div class="row">
                     
                     <div class="col-sm ">
                        <h4 class="pt-2 pb-2"><b>Navigation</b></h4>
                        <ul>
                           <li><a href="yoga-practitioners.php">Practitioners</a></li>
                           <li><a href="trainers.php">Trainers</a></li>
                           <!--<li><a href="#">Organizations</a></li>-->
                           <!--<li><a href="#">Products</a></li>-->
                           <li><a href="https://wellnesys.com/about-us.html">About Us</a></li>
                        </ul>
                     </div>
                     <div class="col-sm">
                        <h4 class="pt-2 pb-2"><b>Company</b></h4>
                        <ul>
                           <li><a href="https://www.yogify.io/cart" target="_blank">Shop</a></li>
                           <li><a href="https://www.wellnesys.com/news.html" target="_blank">News & Press</a></li>
                           <!--<li><a href="https://www.yogify.io/account/login" target="_blank">Sign In</a></li>-->
                           <li><a href="https://www.wellnesys.com/contact-us.html" target="_blank">Contact Us</a></li>
                        </ul>
                     </div>
                     <div class="col-sm">
                        
                     </div>
                  </div>
               </div>
               <div class="col-12 col-md-4 ">
                  <div class=" text-right">
                  <img src="images/logo_black.png" class="img-fluid" >
                  <p class="pt-3">YogiFi is a smart virtual yoga instructor that offers personalized wellness programs on an intelligent yoga mat that tracks various exercise, postures, provides real-time correctional feedback, and correlates body vitals from wearables.</p>
                 
               </div>
               </div>
            </div>
            <div class="row mt-md-3">
            <div class="col-sm border-top copyright ">
               <div class="mb-4 mb-md-0 pt-md-3 "><p class="d-inline ">International Patent Pending. Copyright @2019. YOGIFI All Rights Reserved</p><a href="http://www.wellnesys.com/privacy.html" target="_blank" class="d-inline pl-md-3">Privacy Policy</a>  <a href="http://www.wellnesys.com/legal.html"  target="_blank" class="d-inline pl-2 pl-md-3">Legal</a></div>
            </div>
             <div class="col-sm solcial mb-center">
                     <ul class="float-right">
                        <!--<li>
                           <a href="https://accounts.google.com/AccountChooser/signinchooser?service=lbc&continue=https%3A%2F%2Fbusiness.google.com%2Fdashboard%2Fl%2F08059107266702732155%3Facct_rdr%3D1&flowName=GlifWebSignIn&flowEntry=AccountChooser" target="_blank"><i class="fa fa-google" aria-hidden="true"></i></a>
                        </li>-->
                        <li>
                           <a href="https://www.linkedin.com/company/wellnesys" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                        </li>
                        <li>
                           <a href="https://www.facebook.com/yogifiio" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        </li>
                        <li>
                           <a href="https://twitter.com/YogiFi_Me" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                        </li>
                        <li>
                           <a href="https://www.instagram.com/p/BkZbUnDBkE4/?hl=en" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                        </li>
                     </ul>
                  </div>
               </div>
         </div>
      </footer><!-- Optional JavaScript -->
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/wow.js"></script> 
      <script src="js/owl.carousel.js"></script>      <script type="text/javascript">
         $(window).scroll(function() {
           if ($(this).scrollTop() > 100){  
               $('.navbar-expand-lg').addClass("navbar-shrink");
             }
             else{
               $('.navbar-expand-lg').removeClass("navbar-shrink");
             }
           });
      </script>
      <script>
         $(document).ready(function() {
           var owl = $('#foodtrought-owl');
           owl.owlCarousel({
             margin: 15,
             nav: false,
             dots: true,
             loop: false,
             navText: [""],
             responsive: {
               0: {
                 items: 1
               },
               600: {
                 items: 2
               },
               1000: {
                 items: 2
               }
             }
           });
         var owl = $('#awards-owl');
           owl.owlCarousel({
             margin: 15,
             nav: true,
             dots: false,
             autoplay:true,
             autoplayTimeout:3000,
             autoplayHoverPause:true,
             loop: false,
             navText: ["<div class='left-nav'><i class='fa fa-angle-left'></i></div>", "<div class='right-nav'><i class='fa fa-angle-right'></i></div>"],
             responsive: {
               0: {
                 items: 1
               },
               600: {
                 items: 2
               },
               1000: {
                 items: 3
               }
             }
           })
            
         })
      </script>
      <script>
         wow = new WOW(
           {
             animateClass: 'animated',
             offset:       100,
             callback:     function(box) {
               console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
             }
           }
         );
         wow.init();
         document.getElementById('moar').onclick = function() {
           var section = document.createElement('section');
           section.className = 'section--purple wow fadeInDown';
           this.parentNode.insertBefore(section, this);
         };
      </script>
      <script type="text/javascript" src="js/custom.js"></script>
      <script type="text/javascript">
         $('.seachbtn').on('click', function(){
           $(this).toggleClass('toggleshow')
           $('.searchBox').toggle().toggleClass('show');
         })
      </script>
   </body>
</html>
