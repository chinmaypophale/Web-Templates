<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta name="google-site-verification" content="VR7nd7-

VfbZSp8MuZzYW0shPxUR2ZJTIgO3g-OdiaU4" />

	<meta name="p:domain_verify" content="95517586d6cd7b5e5e6edc420762c8cd" />
	<meta charset="UTF-8" />
	
	<title> |   Page not found</title>

	
			
							<meta name="keywords" content="VR7nd7-VfbZSp8MuZzYW0shPxUR2ZJTIgO3g-OdiaU4">
						<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
		
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="http://ganeshbhel.com/xmlrpc.php" />
            <link rel="shortcut icon" type="image/x-icon" href="http://ganeshbhel.com/wp-content/uploads/2018/07/frame-icon-01.png">
        <link rel="apple-touch-icon" href="http://ganeshbhel.com/wp-content/uploads/2018/07/frame-icon-01.png"/>
    	<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
			<style>

			
				#icon_wrapper

				{

				position: fixed;

				top: 25%;

				right: 0px;

				z-index: 99999;

				}

			
			.awesome-social

			{

                margin-top:2px;

			color: white !important;

			text-align: center !important;

			
			line-height: 34px !important;

			width: 32px !important;

			height: 32px !important;

			font-size: 1.5em !important;

			


			text-shadow: 2px 2px 4px #000000;
			
				-moz-transition: width s, height s, -webkit-transform s; /* For Safari 3.1 to 6.0 */



				-webkit-transition: width s, height s, -webkit-transform s; /* For Safari 3.1 to 6.0 */

				transition: width s, height s, transform s;



				


			}

			
			.awesome-social:hover

			{



			-webkit-transform: rotate(360deg); /* Chrome, Safari, Opera */

				transform: rotate(deg);

					-moz-transform: rotate(360deg); /* Chrome, Safari, Opera */

							-ms-transform: rotate(360deg); /* Chrome, Safari, Opera */



			}

				
			.fuse_social_icons_links

			{

			outline:0 !important;



			}

			.fuse_social_icons_links:hover{

			text-decoration:none !important;

			}

			
			.fb-awesome-social

			{

			background: #3b5998;

			}

			.tw-awesome-social

			{

			background:#00aced;

			}

			.rss-awesome-social

			{

			background:#FA9B39;

			}

			.linkedin-awesome-social

			{

			background:#007bb6;

			}

			.youtube-awesome-social

			{

			background:#bb0000;

			}

			.flickr-awesome-social

			{

			background: #ff0084;

			}

			.pinterest-awesome-social

			{

			background:#cb2027;

			}

			.stumbleupon-awesome-social

			{

			background:#f74425 ;

			}

			.google-plus-awesome-social

			{

			background:#f74425 ;

			}

			.instagram-awesome-social

			{

			background:#517fa4 ;

			}

			.tumblr-awesome-social

			{

			background: #32506d ;

			}

			.vine-awesome-social

			{

			background: #00bf8f ;

			}

            .vk-awesome-social {



            background: #45668e ;



            }

            .soundcloud-awesome-social

                {

            background: #ff3300 ;



                }

                .reddit-awesome-social{



            background: #ff4500 ;



                }

                .stack-awesome-social{



            background: #fe7a15 ;



                }

                .behance-awesome-social{

            background: #1769ff ;



                }

                .github-awesome-social{

            background: #999999 ;





                }

                .envelope-awesome-social{

                  background: #ccc ;

                }

/*  Mobile */






/* Custom Background */


             
             .awesome-social{



-webkit-transition-property:color, text;

-webkit-transition-duration: 0.25s, 0.25s;

-webkit-transition-timing-function: linear, ease-in;

-moz-transition-property:color, text;

-moz-transition-duration:0.25s;

-moz-transition-timing-function: linear, ease-in;



-o-transition-property:color, text;

-o-transition-duration:0.25s;

-o-transition-timing-function: linear, ease-in;

             }

            .fb-awesome-social:hover

			{

			color: #3b5998 !important;

			}

			.tw-awesome-social:hover

			{

			color:#00aced !important;

			}

			.rss-awesome-social:hover

			{

			color:#FA9B39 !important;

			}

			.linkedin-awesome-social:hover

			{

			color:#007bb6 !important;

			}

			.youtube-awesome-social:hover

			{

			color:#bb0000 !important;

			}

			.flickr-awesome-social:hover

			{

			color: #ff0084 !important;

			}

			.pinterest-awesome-social:hover

			{

			color:#cb2027 !important;

			}

			.stumbleupon-awesome-social:hover

			{

			color:#f74425  !important;

			}

			.google-plus-awesome-social:hover

			{

			color:#f74425  !important;

			}

			.instagram-awesome-social:hover

			{

			color:#517fa4  !important;

			}

			.tumblr-awesome-social:hover

			{

			color: #32506d  !important;

			}

			.vine-awesome-social:hover

			{

			color: #00bf8f  !important;

			}



            .vk-awesome-social:hover {



            color: #45668e !important;



            }

            .soundcloud-awesome-social:hover

                {

            color: #ff3300 !important;



                }

                .reddit-awesome-social:hover{



            color: #ff4500 !important;



                }

                .stack-awesome-social:hover{



            color: #fe7a15 !important;



                }

                .behance-awesome-social:hover{

            color: #1769ff !important;



                }

                .github-awesome-social:hover{

            color: #999999 !important;





                }





                 




			</style>

<link href='//fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900,300italic,400italic,700italic|Montserrat:100,200,300,400,500,600,700,800,900,300italic,400italic,700italic|Encode+Sans+Semi+Condensed:100,200,300,400,500,600,700,800,900,300italic,400italic,700italic|Playfair+Display:100,200,300,400,500,600,700,800,900,300italic,400italic,700italic|Raleway:100,200,300,400,500,600,700,800,900,300italic,400italic,700italic&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
<script type="application/javascript">var QodeAjaxUrl = "http://ganeshbhel.com/wp-admin/admin-ajax.php"</script><link rel='dns-prefetch' href='//maps.googleapis.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title=" &raquo; Feed" href="http://ganeshbhel.com/feed/" />
<link rel="alternate" type="application/rss+xml" title=" &raquo; Comments Feed" href="http://ganeshbhel.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/ganeshbhel.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.11"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='layerslider-css'  href='http://ganeshbhel.com/wp-content/plugins/LayerSlider/static/layerslider/css/layerslider.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='http://ganeshbhel.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='cf7cf-style-css'  href='http://ganeshbhel.com/wp-content/plugins/cf7-conditional-fields/style.css?ver=1.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='image-zoom-inout-css'  href='http://ganeshbhel.com/wp-content/plugins/image-zoom-in-out/image-zoom-inout.css?ver=4.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='image-hover-effects-css-css'  href='http://ganeshbhel.com/wp-content/plugins/mega-addons-for-visual-composer/css/ihover.css?ver=4.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='style-css-css'  href='http://ganeshbhel.com/wp-content/plugins/mega-addons-for-visual-composer/css/style.css?ver=4.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-latest-css'  href='http://ganeshbhel.com/wp-content/plugins/mega-addons-for-visual-composer/css/font-awesome/css/font-awesome.css?ver=4.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://ganeshbhel.com/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.7.1' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='default_style-css'  href='http://ganeshbhel.com/wp-content/themes/bridge/style.css?ver=4.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='qode_font_awesome-css'  href='http://ganeshbhel.com/wp-content/themes/bridge/css/font-awesome/css/font-awesome.min.css?ver=4.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='qode_font_elegant-css'  href='http://ganeshbhel.com/wp-content/themes/bridge/css/elegant-icons/style.min.css?ver=4.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='qode_linea_icons-css'  href='http://ganeshbhel.com/wp-content/themes/bridge/css/linea-icons/style.css?ver=4.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='qode_dripicons-css'  href='http://ganeshbhel.com/wp-content/themes/bridge/css/dripicons/dripicons.css?ver=4.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='stylesheet-css'  href='http://ganeshbhel.com/wp-content/themes/bridge/css/stylesheet.min.css?ver=4.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-css'  href='http://ganeshbhel.com/wp-content/themes/bridge/css/woocommerce.min.css?ver=4.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce_responsive-css'  href='http://ganeshbhel.com/wp-content/themes/bridge/css/woocommerce_responsive.min.css?ver=4.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='qode_print-css'  href='http://ganeshbhel.com/wp-content/themes/bridge/css/print.css?ver=4.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='style_dynamic-css'  href='http://ganeshbhel.com/wp-content/themes/bridge/css/style_dynamic.css?ver=1539248116' type='text/css' media='all' />
<link rel='stylesheet' id='responsive-css'  href='http://ganeshbhel.com/wp-content/themes/bridge/css/responsive.min.css?ver=4.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='style_dynamic_responsive-css'  href='http://ganeshbhel.com/wp-content/themes/bridge/css/style_dynamic_responsive.css?ver=1537263946' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css'  href='http://ganeshbhel.com/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=5.4.7' type='text/css' media='all' />
<link rel='stylesheet' id='custom_css-css'  href='http://ganeshbhel.com/wp-content/themes/bridge/css/custom_css.css?ver=1537263946' type='text/css' media='all' />
<link rel='stylesheet' id='popup-maker-site-css'  href='//ganeshbhel.com/wp-content/uploads/pum/pum-site-styles.css?generated=1533970986&#038;ver=1.7.29' type='text/css' media='all' />
<link rel='stylesheet' id='redux-google-fonts-splite_opts-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A700%7CNoto+Sans&#038;ver=1534853621' type='text/css' media='all' />
<script type='text/javascript'>
/* <![CDATA[ */
var LS_Meta = {"v":"6.7.1"};
/* ]]> */
</script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/LayerSlider/static/layerslider/js/greensock.js?ver=1.19.0'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/LayerSlider/static/layerslider/js/layerslider.kreaturamedia.jquery.js?ver=6.7.1'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/LayerSlider/static/layerslider/js/layerslider.transitions.js?ver=6.7.1'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/mega-addons-for-visual-composer/js/script.js?ver=4.9.11'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.7.1'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.7.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"http:\/\/ganeshbhel.com","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=3.4.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=5.4.7'></script>
<meta name="generator" content="Powered by LayerSlider 6.7.1 - Multi-Purpose, Responsive, Parallax, Mobile-Friendly Slider Plugin for WordPress." />
<!-- LayerSlider updates and docs at: https://layerslider.kreaturamedia.com -->
<link rel='https://api.w.org/' href='http://ganeshbhel.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://ganeshbhel.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://ganeshbhel.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.11" />
<meta name="generator" content="WooCommerce 3.4.4" />
	<!-- Olympus Google Fonts CSS - https://wordpress.org/plugins/olympus-google-fonts/ -->
	<style>
						
		/* Advanced Settings */

																			</style>
	<!-- Olympus Google Fonts CSS -->
		<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="http://ganeshbhel.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><meta name="generator" content="Powered by Slider Revolution 5.4.7.1 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />

<!-- BEGIN ExactMetrics v5.3.5 Universal Analytics - https://exactmetrics.com/ -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-121195515-1', 'auto');
  ga('send', 'pageview');
</script>
<!-- END ExactMetrics Universal Analytics -->
<script type="text/javascript">function setREVStartSize(e){									
						try{ e.c=jQuery(e.c);var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;
							if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
						}catch(d){console.log("Failure at Presize of Slider:"+d)}						
					};</script>
<style type="text/css" title="dynamic-css" class="options-output">{color:#f74c1d;}{color:#EFEFEF;}{color:#EFEFEF;}{background-color:#f74c1d;}</style><noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>	
	
	
	
	
	<script type='text/javascript'>

(function()
{
  if( window.localStorage )
  {
    if( !localStorage.getItem( 'firstLoad' ) )
    {
      localStorage[ 'firstLoad' ] = true;
      window.location.reload();
    }  
    else
      localStorage.removeItem( 'firstLoad' );
  }
})();

</script>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
</head>

<body class="error404 woocommerce-no-js ajax_fade page_not_loaded  qode_grid_1400 columns-4 qode-theme-ver-13.9 qode-theme-bridge disabled_footer_bottom wpb-js-composer js-comp-ver-5.4.7 vc_responsive elementor-default" itemscope itemtype="http://schema.org/WebPage">

	
	
	
	
	<div class="ajax_loader"><div class="ajax_loader_1"><div class="two_rotating_circles"><div class="dot1"></div><div class="dot2"></div></div></div></div>
	
<div class="wrapper">
	<div class="wrapper_inner">

    
    <!-- Google Analytics start -->
            <script>
            var _gaq = _gaq || [];
            _gaq.push(['_setAccount', 'UA-124641160-1']);
            _gaq.push(['_trackPageview']);

            (function() {
                var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
            })();
        </script>
        <!-- Google Analytics end -->

	<header class=" scroll_header_top_area dark stick scrolled_not_transparent page_header">
	<div class="header_inner clearfix">
				<div class="header_top_bottom_holder">
			
			<div class="header_bottom clearfix" style='' >
								<div class="container">
					<div class="container_inner clearfix">
																				<div class="header_inner_left">
																	<div class="mobile_menu_button">
		<span>
			<i class="qode_icon_font_awesome fa fa-bars " ></i>		</span>
	</div>
								<div class="logo_wrapper" >
	<div class="q_logo">
		<a itemprop="url" href="http://ganeshbhel.com/" >
             <img itemprop="image" class="normal" src="http://ganeshbhel.com/wp-content/themes/bridge/img/logo.png" alt="Logo"/> 			 <img itemprop="image" class="light" src="http://ganeshbhel.com/wp-content/uploads/2018/06/logo-1.png" alt="Logo"/> 			 <img itemprop="image" class="dark" src="http://ganeshbhel.com/wp-content/uploads/2018/06/logo-1.png" alt="Logo"/> 			 <img itemprop="image" class="sticky" src="http://ganeshbhel.com/wp-content/uploads/2018/06/logo-1.png" alt="Logo"/> 			 <img itemprop="image" class="mobile" src="http://ganeshbhel.com/wp-content/uploads/2018/06/logo-1.png" alt="Logo"/> 			 <img itemprop="image" class="popup" src="http://ganeshbhel.com/wp-content/uploads/2018/06/logo-1.png" alt="Logo"/> 		</a>
	</div>
	</div>															</div>
															<div class="header_inner_right">
									<div class="side_menu_button_wrapper right">
																														<div class="side_menu_button">
																																											</div>
									</div>
								</div>
							
							
							<nav class="main_menu drop_down right">
								<ul id="menu-top_menu" class=""><li id="nav-menu-item-15589" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home  narrow"><a href="http://ganeshbhel.com/" class=""><i class="menu_icon blank fa"></i><span>Home</span><span class="plus"></span></a></li>
<li id="nav-menu-item-15599" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="http://ganeshbhel.com/about/" class=""><i class="menu_icon blank fa"></i><span>About</span><span class="plus"></span></a></li>
<li id="nav-menu-item-15598" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="http://ganeshbhel.com/product/" class=""><i class="menu_icon blank fa"></i><span>Product</span><span class="plus"></span></a></li>
<li id="nav-menu-item-17209" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="http://ganeshbhel.com/catering-service-provider-in-pune/" class=""><i class="menu_icon blank fa"></i><span>Services</span><span class="plus"></span></a></li>
<li id="nav-menu-item-15478" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="http://ganeshbhel.com/stores/" class=""><i class="menu_icon blank fa"></i><span>Stores</span><span class="plus"></span></a></li>
<li id="nav-menu-item-16401" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="http://ganeshbhel.com/blog/" class=""><i class="menu_icon blank fa"></i><span>Blog</span><span class="plus"></span></a></li>
<li id="nav-menu-item-15476" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="http://ganeshbhel.com/contact/" class=""><i class="menu_icon blank fa"></i><span>Contact</span><span class="plus"></span></a></li>
</ul>							</nav>
														<nav class="mobile_menu">
	<ul id="menu-top_menu-1" class=""><li id="mobile-menu-item-15589" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="http://ganeshbhel.com/" class=""><span>Home</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
<li id="mobile-menu-item-15599" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="http://ganeshbhel.com/about/" class=""><span>About</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
<li id="mobile-menu-item-15598" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="http://ganeshbhel.com/product/" class=""><span>Product</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
<li id="mobile-menu-item-17209" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="http://ganeshbhel.com/catering-service-provider-in-pune/" class=""><span>Services</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
<li id="mobile-menu-item-15478" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="http://ganeshbhel.com/stores/" class=""><span>Stores</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
<li id="mobile-menu-item-16401" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="http://ganeshbhel.com/blog/" class=""><span>Blog</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
<li id="mobile-menu-item-15476" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="http://ganeshbhel.com/contact/" class=""><span>Contact</span></a><span class="mobile_arrow"><i class="fa fa-angle-right"></i><i class="fa fa-angle-down"></i></span></li>
</ul></nav>																				</div>
					</div>
									</div>
			</div>
		</div>

</header>	<a id="back_to_top" href="#">
        <span class="fa-stack">
            <i class="qode_icon_font_awesome fa fa-arrow-up " ></i>        </span>
	</a>
	
	
    
    
    <div class="content ">
            <div class="meta">

            
        <div class="seo_title"> |   Page not found</div>

        


                                        <div class="seo_keywords">VR7nd7-VfbZSp8MuZzYW0shPxUR2ZJTIgO3g-OdiaU4</div>
            
            <span id="qode_page_id">0</span>
            <div class="body_classes">error404,woocommerce-no-js,ajax_fade,page_not_loaded,,qode_grid_1400,columns-4,qode-theme-ver-13.9,qode-theme-bridge,disabled_footer_bottom,wpb-js-composer js-comp-ver-5.4.7,vc_responsive,elementor-default</div>
        </div>
        <div class="content_inner  ">
    <style type="text/css" id="stylesheet-inline-css--1"> .error404.disabled_footer_top .footer_top_holder, .error404.disabled_footer_bottom .footer_bottom_holder { display: none;}

</style></body>

</html>
				<div class="title_outer title_without_animation"    data-height="800px">
		<div class="title title_size_large  position_center  has_fixed_background " style="background-image:url(http://localhost/resto/wp-content/uploads/2014/06/titleimg1-4.jpg);height:800pxpx;">
			<div class="image not_responsive"><img itemprop="image" src="http://localhost/resto/wp-content/uploads/2014/06/titleimg1-4.jpg" alt="&nbsp;" /> </div>
										<div class="title_holder"  style="padding-top:67px;height:733px;">
					<div class="container">
						<div class="container_inner clearfix">
								<div class="title_subtitle_holder" >
                                                                									<div class="title_subtitle_holder_inner">
																										<h1 ><span>404 - Page not found</span></h1>
																			<span class="separator small center"  ></span>
																	
																																			</div>
								                                                            </div>
						</div>
					</div>
				</div>
								</div>
			</div>
			<div class="container">
                				<div class="container_inner default_template_holder">
					<div class="page_not_found">
						<h2> The page you are looking for is not found </h2>
                        <p> The page you are looking for does not exist. It may have been moved, or removed altogether. Perhaps you can return back to the site’s homepage and see if you can find what you are looking for. </p>
						<div class="separator  transparent center  " style="margin-top:35px;"></div>
						<p><a itemprop="url" class="qbutton with-shadow" href="http://ganeshbhel.com/"> Back to homepage </a></p>
						<div class="separator  transparent center  " style="margin-top:35px;"></div>
					</div>
				</div>
                			</div>
				<div class="content_bottom" >
					</div>
				
	</div>
</div>



	<footer >
		<div class="footer_inner clearfix">
				<div class="footer_top_holder">
            			<div class="footer_top">
								<div class="container">
					<div class="container_inner">
																	<div class="four_columns clearfix">
								<div class="column1 footer_col1">
									<div class="column_inner">
										<div id="text-16" class="widget widget_text">			<div class="textwidget"></div>
		</div><div id="custom_html-2" class="widget_text widget widget_custom_html"><div class="textwidget custom-html-widget"><h2>Ganesh Bhel</h2>

<p>
	Almost 4 decades ago when entrepreneur Ramesh Gudmewar coined the term Pani Puri, little did he know that he was spurring a whole new story of taste, bringing a whole new experience for generations to come.
</p></div></div>									</div>
								</div>
								<div class="column2 footer_col2">
									<div class="column_inner">
										<div id="nav_menu-6" class="widget widget_nav_menu"><div class="menu-top_menu-container"><ul id="menu-top_menu-2" class="menu"><li id="menu-item-15589" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-15589"><a href="http://ganeshbhel.com/">Home</a></li>
<li id="menu-item-15599" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15599"><a href="http://ganeshbhel.com/about/">About</a></li>
<li id="menu-item-15598" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15598"><a href="http://ganeshbhel.com/product/">Product</a></li>
<li id="menu-item-17209" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-17209"><a href="http://ganeshbhel.com/catering-service-provider-in-pune/">Services</a></li>
<li id="menu-item-15478" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15478"><a href="http://ganeshbhel.com/stores/">Stores</a></li>
<li id="menu-item-16401" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16401"><a href="http://ganeshbhel.com/blog/">Blog</a></li>
<li id="menu-item-15476" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15476"><a href="http://ganeshbhel.com/contact/">Contact</a></li>
</ul></div></div>									</div>
								</div>
								<div class="column3 footer_col3">
									<div class="column_inner">
										<div id="custom_html-6" class="widget_text widget widget_custom_html"><div class="textwidget custom-html-widget"><h3>Head Office Address:</h3>

<p> 1 Ambe-Shree Apts,</p>
<p>	Ganeshnagar,Pune 411038,</p>
<p> Maharashtra. </p>

<a href="tel:+91 8421301646">
<p>Mobile: +91 8421301646</p> </a>


<a href="tel:+91 9822661176">
<p> +91 9822661176</p>  </a>

<a href="https://mail.google.com/mail/?view=cm&fs=1&to=info@ganeshbhel.com&su=SUBJECT&body=BODY" target="_blank">

E-mail :info@ganeshbhel.com</a>


</div></div>									</div>
								</div>
								<div class="column4 footer_col4">
									<div class="column_inner">
										<span class='q_social_icon_holder circle_social' data-hover-background-color=#ffffff data-hover-color=black><a itemprop='url' href='https://www.youtube.com/channel/UCKNi7WmnOI__xhFZSpemRcQ' target='_blank'><span class='fa-stack ' style='background-color: #bb0000;font-size: 24px;'><i class="qode_icon_font_awesome fa fa-youtube " style="font-size: 24px;" ></i></span></a></span><span class='q_social_icon_holder circle_social' data-hover-background-color=#eeeeee data-hover-color=black><a itemprop='url' href='https://plus.google.com/u/0/117277576368197190484' target='_blank'><span class='fa-stack ' style='background-color: #f74425;font-size: 24px;'><i class="qode_icon_font_awesome fa fa-google-plus " style="font-size: 24px;" ></i></span></a></span><span class='q_social_icon_holder circle_social' data-hover-background-color=#eeeeee data-hover-color=black><a itemprop='url' href=' https://www.instagram.com/ganeshbheloriginal1978/ ' target='_blank'><span class='fa-stack ' style='background-color: #517fa4;font-size: 24px;'><i class="qode_icon_font_awesome fa fa-instagram " style="font-size: 24px;" ></i></span></a></span><span class='q_social_icon_holder circle_social' data-hover-background-color=#eeeeee data-hover-color=black><a itemprop='url' href='https://www.facebook.com/ganeshbheloriginal/  ' target='_blank'><span class='fa-stack ' style='background-color: #3b5998;font-size: 24px;'><i class="qode_icon_font_awesome fa fa-facebook " style="font-size: 24px;" ></i></span></a></span><span class='q_social_icon_holder circle_social' data-color=#ffffff data-hover-background-color=#eeeeee data-hover-color=black><a itemprop='url' href='https://in.pinterest.com/ganeshbhel1978/  ' target='_blank'><span class='fa-stack ' style='background-color: #cb2027;font-size: 24px;'><i class="qode_icon_font_awesome fa fa-pinterest " style="color: #ffffff;font-size: 24px;" ></i></span></a></span><span class='q_social_icon_holder circle_social' data-color=#ffffff data-hover-background-color=#eeeeee data-hover-color=black><a itemprop='url' href=' https://twitter.com/GaneshbhelGBCPP    ' target='_blank'><span class='fa-stack ' style='background-color: #00aced;font-size: 24px;'><i class="qode_icon_font_awesome fa fa-twitter " style="color: #ffffff;font-size: 24px;" ></i></span></a></span>									</div>
								</div>
							</div>
															</div>
				</div>
							</div>
							<svg class="angled-section svg-footer-bottom" preserveAspectRatio="none" viewBox="0 0 86 86" width="100%" height="86">
											<polygon points="0,86 86,0 86,86" />
									</svg>
					</div>
							<div class="footer_bottom_holder">
                								<div class="container">
					<div class="container_inner">
										<div class="three_columns footer_bottom_columns clearfix">
					<div class="column1 footer_bottom_column">
						<div class="column_inner">
							<div class="footer_bottom">
															</div>
						</div>
					</div>
					<div class="column2 footer_bottom_column">
						<div class="column_inner">
							<div class="footer_bottom">
															</div>
						</div>
					</div>
					<div class="column3 footer_bottom_column">
						<div class="column_inner">
							<div class="footer_bottom">
															</div>
						</div>
					</div>
				</div>
									</div>
			</div>
						</div>
				</div>
	</footer>
		
</div>
</div>
<script>
function gtag_report_conversion(url) {
  var callback = function () {
    if (typeof(url) != 'undefined') {
      window.location = url;
    }
  };
  gtag('event', 'conversion', {
      'send_to': 'AW-790077009/b7yTCJvWq4gBENG83vgC',
      'event_callback': callback
  });
  return false;
}
</script><div id="pum-17034" class="pum pum-overlay pum-theme-17028 pum-theme-default-theme popmake-overlay click_open" data-popmake="{&quot;id&quot;:17034,&quot;slug&quot;:&quot;pop-up&quot;,&quot;theme_id&quot;:17028,&quot;cookies&quot;:[],&quot;triggers&quot;:[{&quot;type&quot;:&quot;click_open&quot;,&quot;settings&quot;:{&quot;extra_selectors&quot;:&quot;&quot;,&quot;cookie_name&quot;:null}}],&quot;mobile_disabled&quot;:null,&quot;tablet_disabled&quot;:null,&quot;meta&quot;:{&quot;display&quot;:{&quot;stackable&quot;:false,&quot;overlay_disabled&quot;:false,&quot;scrollable_content&quot;:false,&quot;disable_reposition&quot;:false,&quot;size&quot;:&quot;medium&quot;,&quot;responsive_min_width&quot;:&quot;0%&quot;,&quot;responsive_min_width_unit&quot;:false,&quot;responsive_max_width&quot;:&quot;100%&quot;,&quot;responsive_max_width_unit&quot;:false,&quot;custom_width&quot;:&quot;640px&quot;,&quot;custom_width_unit&quot;:false,&quot;custom_height&quot;:&quot;380px&quot;,&quot;custom_height_unit&quot;:false,&quot;custom_height_auto&quot;:false,&quot;location&quot;:&quot;center top&quot;,&quot;position_from_trigger&quot;:false,&quot;position_top&quot;:&quot;100&quot;,&quot;position_left&quot;:&quot;0&quot;,&quot;position_bottom&quot;:&quot;0&quot;,&quot;position_right&quot;:&quot;0&quot;,&quot;position_fixed&quot;:false,&quot;animation_type&quot;:&quot;fade&quot;,&quot;animation_speed&quot;:&quot;350&quot;,&quot;animation_origin&quot;:&quot;center top&quot;,&quot;overlay_zindex&quot;:false,&quot;zindex&quot;:&quot;1999999999&quot;},&quot;close&quot;:{&quot;text&quot;:&quot;&quot;,&quot;button_delay&quot;:&quot;0&quot;,&quot;overlay_click&quot;:false,&quot;esc_press&quot;:false,&quot;f4_press&quot;:false},&quot;click_open&quot;:[]}}" role="dialog" aria-hidden="true" >

	<div id="popmake-17034" class="pum-container popmake theme-17028 pum-responsive pum-responsive-medium responsive size-medium">

				

				

		

				<div class="pum-content popmake-content">
			<div role="form" class="wpcf7" id="wpcf7-f17010-o2" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="/jquery.themepunch.revolution.js#wpcf7-f17010-o2" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="17010" />
<input type="hidden" name="_wpcf7_version" value="5.0.3" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f17010-o2" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7cf_hidden_group_fields" value="" />
<input type="hidden" name="_wpcf7cf_hidden_groups" value="" />
<input type="hidden" name="_wpcf7cf_visible_groups" value="" />
<input type="hidden" name="_wpcf7cf_options" value="{&quot;form_id&quot;:17010,&quot;conditions&quot;:[],&quot;settings&quot;:false}" />
</div>
<p><label> Your Name (required)<br />
    <span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" /></span> </label></p>
<p><label> Your Email (required)<br />
    <span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" /></span> </label></p>
<p><label> Phone (required)<br />
    <span class="wpcf7-form-control-wrap your-phone"><input type="text" name="your-phone" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" /></span> </label></p>
<p><label><br />
Party Order<br />
<span class="wpcf7-form-control-wrap menu-622"><select name="menu-622" class="wpcf7-form-control wpcf7-select" aria-invalid="false"><option value="select Party Order">select Party Order</option><option value="Party Order">Party Order</option><option value="Corporate &amp; Catering">Corporate &amp; Catering</option><option value="Wedding or Occasional">Wedding or Occasional</option></select></span><br />
</label></p>
<p><label> Your Message<br />
    <span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false"></textarea></span> </label></p>
<p><input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit" /></p>
<input type='hidden' class='wpcf7-pum' value='{"closepopup":false,"closedelay":0,"openpopup":false,"openpopup_id":0}' /><div class="wpcf7-response-output wpcf7-display-none"></div></form></div>
		</div>


				

				            <button type="button" class="pum-close popmake-close" aria-label="Close">
			CLOSE            </button>
		
	</div>

</div>
	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/ganeshbhel.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};
var wpcf7 = {"apiSettings":{"root":"http:\/\/ganeshbhel.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.0.3'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=3.4.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_97cb14901c77994c5e1f2fab86fedfea","fragment_name":"wc_fragments_97cb14901c77994c5e1f2fab86fedfea"};
/* ]]> */
</script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=3.4.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7_redirect_forms = {"17020":{"page_id":"","external_url":"","use_external_url":"","http_build_query":"","open_in_new_tab":"","after_sent_script":"","thankyou_page_url":""},"17015":{"page_id":"16515","external_url":"","use_external_url":"","http_build_query":"","open_in_new_tab":"","after_sent_script":"","thankyou_page_url":"http:\/\/ganeshbhel.com\/thank-you\/"},"17014":{"page_id":"16515","external_url":"","use_external_url":"","http_build_query":"","open_in_new_tab":"","after_sent_script":"","thankyou_page_url":"http:\/\/ganeshbhel.com\/thank-you\/"},"17010":{"page_id":"16515","external_url":"","use_external_url":"","http_build_query":"","open_in_new_tab":"","after_sent_script":"","thankyou_page_url":"http:\/\/ganeshbhel.com\/thank-you\/"},"16338":{"page_id":"0","external_url":"","use_external_url":"","http_build_query":"","open_in_new_tab":"","after_sent_script":"","thankyou_page_url":""},"16337":{"page_id":"","external_url":"","use_external_url":"","http_build_query":"","open_in_new_tab":"","after_sent_script":"","thankyou_page_url":""}};
/* ]]> */
</script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/wpcf7-redirect/js/wpcf7-redirect-script.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var qodeLike = {"ajaxurl":"http:\/\/ganeshbhel.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/plugins/qode-like.min.js?ver=4.9.11'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/accordion.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/position.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/menu.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/wp-a11y.min.js?ver=4.9.11'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var uiAutocompleteL10n = {"noResults":"No results found.","oneResult":"1 result found. Use up and down arrow keys to navigate.","manyResults":"%d results found. Use up and down arrow keys to navigate.","itemSelected":"Item selected."};
/* ]]> */
</script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/autocomplete.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/button.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4'></script>
<script type='text/javascript'>
jQuery(document).ready(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":false});});
</script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/mouse.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/resizable.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/draggable.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/dialog.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/droppable.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/progressbar.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/selectable.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/sortable.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/slider.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/spinner.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/tooltip.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/tabs.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect-blind.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect-bounce.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect-clip.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect-drop.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect-explode.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect-fade.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect-fold.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect-highlight.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect-pulsate.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect-size.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect-scale.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect-shake.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect-slide.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/jquery/ui/effect-transfer.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/plugins.js?ver=4.9.11'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/plugins/jquery.carouFredSel-6.2.1.min.js?ver=4.9.11'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/plugins/lemmon-slider.min.js?ver=4.9.11'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/plugins/jquery.fullPage.min.js?ver=4.9.11'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/plugins/jquery.mousewheel.min.js?ver=4.9.11'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/plugins/jquery.touchSwipe.min.js?ver=4.9.11'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/js_composer/assets/lib/bower/isotope/dist/isotope.pkgd.min.js?ver=5.4.7'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/plugins/packery-mode.pkgd.min.js?ver=4.9.11'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/plugins/jquery.stretch.js?ver=4.9.11'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/plugins/imagesloaded.js?ver=4.9.11'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/plugins/rangeslider.min.js?ver=4.9.11'></script>
<script type='text/javascript' src='https://maps.googleapis.com/maps/api/js?ver=4.9.11'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var no_ajax_obj = {"no_ajax_pages":["http:\/\/ganeshbhel.com\/product\/sunglasses-case\/","http:\/\/ganeshbhel.com\/product\/madrid-weekend-bag\/","http:\/\/ganeshbhel.com\/product\/leather-vanity-case\/","http:\/\/ganeshbhel.com\/product\/tablet-sleeve\/","http:\/\/ganeshbhel.com\/product\/leather-weekend-bag\/","http:\/\/ganeshbhel.com\/product\/vintage-handbag\/","http:\/\/ganeshbhel.com\/product\/travel-leather-bag\/","http:\/\/ganeshbhel.com\/product\/vintage-travel-bag\/","http:\/\/ganeshbhel.com\/product\/smartphone-cover\/","http:\/\/ganeshbhel.com\/product\/leather-briefcase\/","http:\/\/ganeshbhel.com\/product\/laptop-leather-sleeve\/","http:\/\/ganeshbhel.com\/product\/chatpati-bhel\/","http:\/\/ganeshbhel.com\/product-tag\/case\/","http:\/\/ganeshbhel.com\/product-tag\/cover\/","http:\/\/ganeshbhel.com\/product-tag\/glasses\/","http:\/\/ganeshbhel.com\/product-tag\/handbag\/","http:\/\/ganeshbhel.com\/product-tag\/handbag-2\/","http:\/\/ganeshbhel.com\/product-tag\/headphones\/","http:\/\/ganeshbhel.com\/product-tag\/iphone\/","http:\/\/ganeshbhel.com\/product-tag\/laptop\/","http:\/\/ganeshbhel.com\/product-tag\/leather\/","http:\/\/ganeshbhel.com\/product-tag\/mountain\/","http:\/\/ganeshbhel.com\/product-tag\/music\/","http:\/\/ganeshbhel.com\/product-tag\/quad-core\/","http:\/\/ganeshbhel.com\/product-tag\/rooter\/","http:\/\/ganeshbhel.com\/product-tag\/running\/","http:\/\/ganeshbhel.com\/product-tag\/shirt\/","http:\/\/ganeshbhel.com\/product-tag\/shoes\/","http:\/\/ganeshbhel.com\/product-tag\/ski\/","http:\/\/ganeshbhel.com\/product-tag\/sleeve\/","http:\/\/ganeshbhel.com\/product-tag\/smartphone\/","http:\/\/ganeshbhel.com\/product-tag\/sunglasses\/","http:\/\/ganeshbhel.com\/product-tag\/sunglasses-2\/","http:\/\/ganeshbhel.com\/product-tag\/tablet\/","http:\/\/ganeshbhel.com\/product-tag\/travel\/","http:\/\/ganeshbhel.com\/product-tag\/tv\/","http:\/\/ganeshbhel.com\/product-category\/uncategorized\/","http:\/\/ganeshbhel.com\/product-tag\/vanity-case\/","http:\/\/ganeshbhel.com\/product-tag\/vintage\/","http:\/\/ganeshbhel.com\/product-tag\/wallet\/","http:\/\/ganeshbhel.com\/product-tag\/watch\/","http:\/\/ganeshbhel.com\/product-tag\/wifi\/","http:\/\/ganeshbhel.com\/product-tag\/workout\/","http:\/\/ganeshbhel.com\/product-category\/bags\/","http:\/\/ganeshbhel.com\/product-category\/cases\/","http:\/\/ganeshbhel.com\/product-category\/covers\/","http:\/\/ganeshbhel.com\/product-category\/notebook\/","http:\/\/ganeshbhel.com\/product-category\/other\/","http:\/\/ganeshbhel.com\/product-category\/phones\/","http:\/\/ganeshbhel.com\/product-category\/skiing\/","http:\/\/ganeshbhel.com\/product-category\/sleeves\/","http:\/\/ganeshbhel.com\/product-category\/sleeves-2\/","http:\/\/ganeshbhel.com\/product-category\/wallets\/","","http:\/\/ganeshbhel.com\/wp-login.php?action=logout&_wpnonce=16f194afe7"]};
/* ]]> */
</script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/default_dynamic.js?ver=1537263946'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var QodeAdminAjax = {"ajaxurl":"http:\/\/ganeshbhel.com\/wp-admin\/admin-ajax.php"};
var qodeGlobalVars = {"vars":{"qodeAddingToCartLabel":"Adding to Cart..."}};
/* ]]> */
</script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/default.min.js?ver=4.9.11'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/custom_js.js?ver=1537263946'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/ajax.min.js?ver=4.9.11'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=5.4.7'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/themes/bridge/js/woocommerce.min.js?ver=4.9.11'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/woocommerce/assets/js/select2/select2.full.min.js?ver=4.0.3'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-content/plugins/cf7-conditional-fields/js/scripts.js?ver=1.3.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var pum_vars = {"version":"1.7.29","ajaxurl":"http:\/\/ganeshbhel.com\/wp-admin\/admin-ajax.php","restapi":"http:\/\/ganeshbhel.com\/wp-json\/pum\/v1","rest_nonce":null,"default_theme":"17028","debug_mode":"","disable_tracking":"","home_url":"\/","message_position":"top","core_sub_forms_enabled":"1","popups":[]};
var ajaxurl = "http:\/\/ganeshbhel.com\/wp-admin\/admin-ajax.php";
var pum_debug_vars = {"debug_mode_enabled":"Popup Maker: Debug Mode Enabled","debug_started_at":"Debug started at:","debug_more_info":"For more information on how to use this information visit https:\/\/docs.wppopupmaker.com\/?utm_medium=js-debug-info&utm_campaign=ContextualHelp&utm_source=browser-console&utm_content=more-info","global_info":"Global Information","localized_vars":"Localized variables","popups_initializing":"Popups Initializing","popups_initialized":"Popups Initialized","single_popup_label":"Popup: #","theme_id":"Theme ID: ","label_method_call":"Method Call:","label_method_args":"Method Arguments:","label_popup_settings":"Settings","label_triggers":"Triggers","label_cookies":"Cookies","label_delay":"Delay:","label_conditions":"Conditions","label_cookie":"Cookie:","label_settings":"Settings:","label_selector":"Selector:","label_mobile_disabled":"Mobile Disabled:","label_tablet_disabled":"Tablet Disabled:","label_event":"Event: %s","triggers":{"click_open":"Click Open","auto_open":"Time Delay \/ Auto Open"},"cookies":{"on_popup_close":"On Popup Close","on_popup_open":"On Popup Open","pum_sub_form_success":"Subscription Form: Successful","pum_sub_form_already_subscribed":"Subscription Form: Already Subscribed","manual":"Manual JavaScript","cf7_form_success":"Contact Form 7 Success"}};
var pum_sub_vars = {"ajaxurl":"http:\/\/ganeshbhel.com\/wp-admin\/admin-ajax.php","message_position":"top"};
var pum_popups = {"pum-17034":{"disable_form_reopen":false,"disable_on_mobile":false,"disable_on_tablet":false,"custom_height_auto":false,"scrollable_content":false,"position_from_trigger":false,"position_fixed":false,"overlay_disabled":false,"stackable":false,"disable_reposition":false,"close_on_overlay_click":false,"close_on_esc_press":false,"close_on_f4_press":false,"theme_id":"17028","size":"medium","responsive_min_width":"0%","responsive_max_width":"100%","custom_width":"640px","custom_height":"380px","animation_type":"fade","animation_speed":"350","animation_origin":"center top","location":"center top","position_top":"100","position_bottom":"0","position_left":"0","position_right":"0","zindex":"1999999999","close_button_delay":"0","triggers":[],"cookies":[],"id":17034,"slug":"pop-up"}};
/* ]]> */
</script>
<script type='text/javascript' src='//ganeshbhel.com/wp-content/uploads/pum/pum-site-scripts.js?defer&#038;generated=1533970986&#038;ver=1.7.29'></script>
<script type='text/javascript' src='http://ganeshbhel.com/wp-includes/js/wp-embed.min.js?ver=4.9.11'></script>
<div id='icon_wrapper'><a  target="_blank"  class='fuse_social_icons_links' href='https://www.facebook.com/ganeshbheloriginal/ '>	<i class='fa fa-facebook fb-awesome-social awesome-social'></i></a><br /><a target="_blank" class='fuse_social_icons_links' href=' https://twitter.com/GaneshbhelGBCPP'>	<i class='fa fa-twitter tw-awesome-social awesome-social'></i></a><br /><a target="_blank" class='fuse_social_icons_links' href='https://www.youtube.com/channel/UCKNi7WmnOI__xhFZSpemRcQ'>	<i class='fa fa-youtube youtube-awesome-social awesome-social'></i></a><br /><a target="_blank" class='fuse_social_icons_links' href='https://in.pinterest.com/ganeshbhel1978/ '>	<i class='fa fa-pinterest pinterest-awesome-social awesome-social'></i></a><br /><a target="_blank" class='fuse_social_icons_links' href='https://plus.google.com/u/0/117277576368197190484 '>	<i class='fa fa-google-plus google-plus-awesome-social awesome-social'></i></a><br /><a target="_blank" class='fuse_social_icons_links' href=' https://www.instagram.com/ganeshbheloriginal1978/ '>	<i class='fa fa-instagram instagram-awesome-social awesome-social'></i></a><br /><style>a.fuse_social_icons_links img { width: 48px; }</style></div></body>
</html>
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/


Served from: ganeshbhel.com @ 2019-09-21 07:36:31 by W3 Total Cache
-->